# WGTIK_2021
Base code for personal website exercise for WGTIK 2021

example result:
[https://adf-telkomuniv.github.io/WGTIK_2021/](https://adf-telkomuniv.github.io/WGTIK_2021/)
